package com.example.webservicedemo;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;


import com.example.webservicedemo.databinding.ActivityMainBinding;

public class MainActivity extends Activity
{
    /** Called when the activity is first created. */
    private static String SOAP_ACTION1 =  "https://www.w3schools.com/xml/CelsiusToFahrenheit";
    // "https://www.w3schools.com/xml/CelsiusToFahrenheit"
    // "https://www.w3schools.com/xml/FahrenheitToCelsius"
    private static String SOAP_ACTION2 = "https://www.w3schools.com/xml/FahrenheitToCelsius";
    private static String NAMESPACE = "https://www.w3schools.com/xml/";
    private static String METHOD_NAME1 = "CelsiusToFahrenheit";
    // CelsiusToFahrenheit
    private static String METHOD_NAME2 = "FahrenheitToCelsius";

   // private static String METHOD_NAME1 = "FahrenheitToCelsius";
   // private static String METHOD_NAME2 = "CelsiusToFahrenheit";
    private static String URL = "https://www.w3schools.com/xml/tempconvert.asmx?wsdl";
    private static final String TAG = "Logging Example";

    Button btnFar,btnCel,btnClear;
    EditText txtFar,txtCel;
    private ActivityMainBinding binding;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
       // btnFar = (Button)findViewById(R.id.btnFar);
        btnFar = binding.btnFar;
       // btnCel = (Button)findViewById(R.id.btnCel);
        btnCel = binding.btnCel;
        // btnClear = (Button)findViewById(R.id.btnClear);
        // btnClear = binding.btnClear;
        btnClear = binding.btnClear;
        // txtFar = (EditText)findViewById(R.id.txtFar);
        txtFar = binding.txtFar;

        // txtCel = (EditText)findViewById(R.id.txtCel);
        txtCel = binding.txtCel;
        btnFar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //Initialize soap request + add parameters  
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                //Use this to add parameters  
                request.addProperty("Fahrenheit",txtFar.getText().toString());
                //Declare the version of the SOAP request  
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                try {
                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                    //this is the actual part that will call the webservice
                    androidHttpTransport.call(SOAP_ACTION1, envelope);
                    // Get the SoapResult from the envelope body.
                    Log.d(TAG,"Hello");
                    SoapObject result = (SoapObject)envelope.bodyIn;
                    //Log.v(TAG,toString(result));

                    if(result != null)
                    {
                        //Get the first property and change the label text
                        txtCel.setText(result.getProperty(0).toString());
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Received an exception " + e.getMessage() );
                    e.printStackTrace();
                }
            }

        });
        btnCel.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //Initialize soap request + add parameters  
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
                //Use this to add parameters  
                request.addProperty("Celsius",txtCel.getText().toString());
                //Declare the version of the SOAP request  
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                try {
                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                    //this is the actual part that will call the webservice
                    androidHttpTransport.call(SOAP_ACTION2, envelope);
                    // Get the SoapResult from the envelope body.
                    SoapObject result = (SoapObject)envelope.bodyIn;
                    Log.v(TAG, "${numerator / denominator}");

                    if(result != null)
                    {
                        //Get the first property and change the label text
                        txtFar.setText(result.getProperty(0).toString());
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                txtCel.setText("");
                txtFar.setText("");
            }
        });
    }
}  